import { z } from "zod";
import { generateAdvice } from "../lib/ai.js";
import { getSupabaseAdmin } from "../lib/supabase.js";

const assistantSchema = z.object({
  domain: z.string().default("general"),
  question: z.string().min(4).max(4000),
  plan: z.string().optional(),
  context: z.any().optional()
});

export function registerAssistantRoute(app) {
  app.post("/api/assistant", async (req, res, next) => {
    try {
      const payload = assistantSchema.parse(req.body);
      const user = req.currentUser;
      const result = await generateAdvice({
        question: payload.question,
        context: payload.context || {},
        plan: payload.plan || user.plan || "starter",
        domain: payload.domain
      });

      const supabase = getSupabaseAdmin();
      if (supabase && !user.isDemo) {
        await supabase.from("usage_events").insert({
          user_id: user.id,
          event_type: "assistant_request",
          payload_json: {
            model: result.model,
            creditsUsed: result.creditsUsed,
            domain: payload.domain
          }
        });
      }

      res.json({
        ok: true,
        text: result.text,
        model: result.model,
        creditsUsed: result.creditsUsed
      });
    } catch (error) {
      next(error);
    }
  });
}
