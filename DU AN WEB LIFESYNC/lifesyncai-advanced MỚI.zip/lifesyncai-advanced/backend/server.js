import express from "express";
import cors from "cors";
import helmet from "helmet";
import { env } from "./lib/env.js";
import { requireUser } from "./lib/auth.js";
import { aiLimiter, generalLimiter } from "./lib/rateLimit.js";
import { registerHealthRoute } from "./api/health.js";
import { registerSyncRoute } from "./api/sync.js";
import { registerAssistantRoute } from "./api/assistant.js";
import { registerPushSubscribeRoute } from "./api/push-subscribe.js";
import { registerPushTestRoute } from "./api/push-test.js";
import { registerCheckoutRoute } from "./api/create-checkout.js";

const app = express();

app.use(helmet({
  crossOriginResourcePolicy: false
}));
app.use(express.json({ limit: "1mb" }));
app.use(cors({
  origin(origin, callback) {
    if (!origin) return callback(null, true);
    if (!env.frontendOrigins.length) return callback(null, true);
    if (env.frontendOrigins.includes(origin)) return callback(null, true);
    return callback(new Error(`Origin not allowed: ${origin}`));
  }
}));
app.use(generalLimiter);

registerHealthRoute(app);

app.use("/api", requireUser);

registerSyncRoute(app);
app.use("/api/assistant", aiLimiter);
registerAssistantRoute(app);
registerPushSubscribeRoute(app);
registerPushTestRoute(app);
registerCheckoutRoute(app);

app.use((error, _req, res, _next) => {
  console.error(error);
  const status = Number(error.status || 500);
  res.status(status).json({
    ok: false,
    error: error.message || "Internal server error"
  });
});

app.listen(env.port, () => {
  console.log(`LifeSync AI backend running at http://localhost:${env.port}`);
});
