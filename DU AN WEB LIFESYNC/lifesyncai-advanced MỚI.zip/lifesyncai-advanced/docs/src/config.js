window.LifeSyncConfig = {
  appName: "LifeSync AI",
  apiBaseUrl: "",
  siteBasePath: "/LifeSyncAI/",
  vapidPublicKey: "",
  supabaseUrl: "",
  supabaseAnonKey: "",
  stripePriceIds: {
    proMonthly: "",
    proYearly: ""
  },
  demoUser: {
    id: "demo-user",
    name: "Demo User",
    email: "demo@lifesync.local",
    plan: "starter"
  }
};
