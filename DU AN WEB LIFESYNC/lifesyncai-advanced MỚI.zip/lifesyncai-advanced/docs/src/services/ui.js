export function toast(message, type = "info") {
  const node = document.getElementById("app-toast");
  if (!node) return;
  node.hidden = false;
  node.textContent = message;
  node.dataset.type = type;
  clearTimeout(node._timeout);
  node._timeout = setTimeout(() => {
    node.hidden = true;
  }, 3200);
}

export function confirmDanger(message) {
  return window.confirm(message);
}

export function installPromptHandler(setReadyState) {
  let deferredPrompt = null;

  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    deferredPrompt = event;
    setReadyState(true, async () => {
      if (!deferredPrompt) return false;
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      deferredPrompt = null;
      setReadyState(false, null);
      return outcome === "accepted";
    });
  });

  return () => deferredPrompt;
}
