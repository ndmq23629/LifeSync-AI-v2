# LifeSync AI — Practical Growth Architecture

Bộ mã này được dựng lại cho hướng **kiếm tiền được trước, mở rộng được sau**:

- **Frontend**: PWA local-first chạy từ thư mục `docs/`
- **Backend**: Node/Express server cho AI proxy, sync, push subscription, Stripe checkout
- **Cloud**: Supabase cho Auth + Postgres + RLS
- **Deploy**:
  - Frontend lên **GitHub Pages**
  - Backend lên **Render / Railway / VPS**
  - Database/Auth trên **Supabase**

## Mục tiêu thiết kế

1. Không còn thông điệp “AI miễn phí vô hạn”.
2. Lấy **Finance + Productivity** làm mũi khoan MVP.
3. Cho phép chạy demo ngay cả khi **chưa cấu hình cloud**.
4. Khi gắn cloud, app nâng cấp lên:
   - đồng bộ đa thiết bị
   - AI insight
   - push notifications
   - thanh toán gói Pro

## Cấu trúc repo

```text
docs/       # Frontend PWA deploy lên GitHub Pages
backend/    # API Node/Express
supabase/   # SQL schema
guides/     # Tài liệu triển khai
.github/    # Workflow deploy Pages
```

## Chạy nhanh

### 1) Frontend local
Mở `docs/index.html` bằng Live Server hoặc bất kỳ static server nào.

### 2) Backend local
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

### 3) Kết nối frontend với backend
Sửa `docs/src/config.js`:

```js
window.LifeSyncConfig = {
  apiBaseUrl: "http://localhost:8787",
  ...
}
```

## Tài liệu
- `guides/DEPLOY_GITHUB_COPILOT.md`
- `guides/ARCHITECTURE.md`
- `guides/MONETIZATION.md`
